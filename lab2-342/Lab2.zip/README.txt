To compile the test file run: g++ -Wall lab2test.cpp Sort*.cpp

To compile the main file run: g++ -Wall lab2main.cpp Sort*.cpp

