#include "store.h"

int main() {
	Store s;
	s.run();
	return 0;
}